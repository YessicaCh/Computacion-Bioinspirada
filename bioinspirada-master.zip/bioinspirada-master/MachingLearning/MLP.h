#ifndef MLP_H_INCLUDED
#define MLP_H_INCLUDED
#include <iostream>
#include <vector>
#include <utility>
using namespace std;



bool MLP(vector < pair<int,int> > entradas, double salidas [])
{
    return 1;
}

#endif // MLP_H_INCLUDED
