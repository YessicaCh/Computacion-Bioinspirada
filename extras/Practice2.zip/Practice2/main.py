from GeneticAlgorithm import GeneticAlg

if __name__ == "__main__":
	maximizer = GeneticAlg(10) # 10 chromosomes
	maximizer.init()